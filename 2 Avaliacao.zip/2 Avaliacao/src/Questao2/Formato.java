package Questao2;

public enum Formato {
	
	XML,
	CSV,
	PORCENTO
}
