package Questao1;

import Conta.Conta;

public interface Investimento {
	
	double investir (Conta conta);
	
}
